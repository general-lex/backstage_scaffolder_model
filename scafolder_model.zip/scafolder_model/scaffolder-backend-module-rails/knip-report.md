# Knip report

## Unused devDependencies (1)

| Name      | Location     | Severity |
| :-------- | :----------- | :------- |
| jest-when | plugins/scaffolder-backend-module-rails/package.json | error    |

