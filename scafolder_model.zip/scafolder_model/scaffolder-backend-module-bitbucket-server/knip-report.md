# Knip report

## Unused dependencies (1)

| Name | Location     | Severity |
| :-- | :----------- | :------- |
| zod | plugins/scaffolder-backend-module-bitbucket-server/package.json | error    |

