# @backstage/plugin-scaffolder-backend-module-bitbucket-server

The Bitbucket Server module for
[@backstage/plugin-scaffolder-backend](https://www.npmjs.com/package/@backstage/plugin-scaffolder-backend).

## Actions

- `publish:bitbucketServer`
- `publish:bitbucketServer:pull-request`
