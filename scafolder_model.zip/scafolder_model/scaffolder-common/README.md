# @backstage/plugin-scaffolder-common

Common types and functionalities for the scaffolder, to be shared between scaffolder and scaffolder-backend.
