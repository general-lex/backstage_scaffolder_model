# Knip report

## Unused devDependencies (3)

| Name             | Location     | Severity |
| :--------------- | :----------- | :------- |
| react-router-dom | plugins/scaffolder-node-test-utils/package.json | error    |
| react-dom        | plugins/scaffolder-node-test-utils/package.json | error    |
| react            | plugins/scaffolder-node-test-utils/package.json | error    |

