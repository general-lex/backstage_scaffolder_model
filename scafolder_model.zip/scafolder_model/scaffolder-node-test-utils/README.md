# @backstage/plugin-scaffolder-node-test-utils

Contains utilities that can be used when testing scaffolder features.

## Installation

Install the package via Yarn into your own packages:

```sh
cd <package-dir> # if within a monorepo
yarn add --dev @backstage/plugin-scaffolder-node-test-utils
```
