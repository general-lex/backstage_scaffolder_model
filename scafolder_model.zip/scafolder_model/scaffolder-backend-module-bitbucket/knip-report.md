# Knip report

## Unused dependencies (1)

| Name     | Location     | Severity |
| :------- | :----------- | :------- |
| fs-extra | plugins/scaffolder-backend-module-bitbucket/package.json | error    |

