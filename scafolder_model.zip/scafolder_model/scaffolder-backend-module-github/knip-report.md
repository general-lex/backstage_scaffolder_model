# Knip report

## Unlisted dependencies (1)

| Name          | Location    | Severity |
| :------------ | :---------- | :------- |
| @octokit/core | plugins/scaffolder-backend-module-github/src/util.ts | error    |

