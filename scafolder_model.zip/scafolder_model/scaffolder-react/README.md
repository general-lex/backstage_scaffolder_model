# Scaffolder React

This is shared code of the frontend part of the default Scaffolder plugin.

It will implement the core API for working with the Scaffolder, and
supplies components that can be reused by third-party plugins.

## Links

- [Frontend part of the plugin](https://github.com/backstage/backstage/tree/master/plugins/scaffolder)
- [Backend part of the plugin](https://github.com/backstage/backstage/tree/master/plugins/scaffolder-backend)
- [The Backstage homepage](https://backstage.io)
