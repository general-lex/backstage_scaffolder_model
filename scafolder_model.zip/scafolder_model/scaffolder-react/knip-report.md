# Knip report

## Unused dependencies (1)

| Name                      | Location     | Severity |
| :------------------------ | :----------- | :------- |
| @backstage/catalog-client | plugins/scaffolder-react/package.json | error    |

## Unused devDependencies (1)

| Name                             | Location     | Severity |
| :------------------------------- | :----------- | :------- |
| @backstage/plugin-catalog-common | plugins/scaffolder-react/package.json | error    |

