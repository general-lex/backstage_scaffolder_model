# Knip report

## Unused dependencies (1)

| Name    | Location     | Severity |
| :------ | :----------- | :------- |
| winston | plugins/scaffolder-backend-module-yeoman/package.json | error    |

