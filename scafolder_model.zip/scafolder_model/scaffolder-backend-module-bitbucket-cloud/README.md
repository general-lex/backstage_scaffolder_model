# @backstage/plugin-scaffolder-backend-module-bitbucket

The [Bitbucket Cloud](https://bitbucket.org) module for
[@backstage/plugin-scaffolder-backend](https://www.npmjs.com/package/@backstage/plugin-scaffolder-backend).

_This plugin was created through the Backstage CLI_

## Actions

- `publish:bitbucketCloud`
- `bitbucket:pipelines:run`
- `publish:bitbucketCloud:pull-request`
